package circulardouble;

public class Dnode {
	int data;
	Dnode left,right;
	public Dnode(int data) {
		this.data=data;
		left=right=null;
	}
}
