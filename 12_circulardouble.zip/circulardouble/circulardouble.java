package circulardouble;

public class circulardouble {
	 Dnode root,left,right;
     void create_list() {
         root = left = right = null;
     }
     void insert_left(int data) {
         Dnode n = new Dnode(data);
         if (root == null)
         {
             root =n;
             n.left=n;
             n.right=n;
           
         }
         else {
            n.right = root;
            n.left = root.left;
            root.left.right=n;
            root.left=n;
            root=n;
         }
         System.out.println(root.data + " inserted");

     }

     void delete_left() {
         if (root == null) {
             System.out.println("Empty List");
         }
         else {
             if(root==null)//single node
                 System.out.println("Empty List");
             else
             {
            	 Dnode t=root;
            	 if(root.right==root) {
            		 root.left.right=root.right;
            		 root.right.left=root.left;
            		 root=root.right;
            	 }
             }
             System.out.println(root.data + " deleted");
         }
     }

     void insert_right(int data) {
         Dnode n = new Dnode(data);
         if (root == null)
         {
        	 root =n;
             n.left=n;
             n.right=n;
         }
         else
         {
        	 n.left = root;
             n.right = root.right;
             root.right.left=n;
             root.right=n;
             root=n;

         }
         System.out.println(root.data + " inserted");

     }

     void delete_right() {
         if (root == null)
             System.out.println("Empty List");
         else {
        	 Dnode n=root;
        	 n = root.left=root.right;//1
             if(root.left==root.right)
                 root.left=root.right=null;
             else
             {
                 while (n != root.right) //2
                 {
                     root.left = n;
                     n = root.right;
                 }
                 root.left=n;//3
                 root.right=root;//4
             }
             System.out.println(n.data + " deleted");
         }
     }

     void print_list() {
         if (root == null)
             System.out.println("List Empty");
         else {
        	 root = root.left=root.right;//n becomes 1st so root
             root.right=root.right=root;
             Dnode t = null;
			do{
                 System.out.print("|" + root.data + "|->");
                 root.left = t;
             } while (t != root);
         }
     }
     void print_list_rev() {
    	 if (root == null)
             System.out.println("List Empty");
         else {
             Dnode t = root;
             while (t.right != null)
                         t = t.right;
             while(t!=null)
             {
                 System.out.print("<-|" + t.data + "|->");
                 t = t.left;
             }
         }

     }

}
